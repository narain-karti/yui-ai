import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

export async function generatePlan(
  params: { query: string, origin: string, destination: string, stops: string[], days: number, tripPurpose?: string, tags: string[], budget: string, calendarEvents?: any[] },
  onEvent: (event: any) => void
) {
  const { query, origin, destination, stops, days, tripPurpose, tags, budget, calendarEvents } = params;
  
  // The platform injects process.env.GEMINI_API_KEY automatically
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

  try {
    // 1. Calendar Scan
    onEvent({ type: 'CALENDAR_SCAN', status: 'scanning', data: { text: 'Analyzing request context...' } });
    
    let contextResText = 'Business Trip';
    if (calendarEvents && calendarEvents.length > 0) {
      const eventsSummary = calendarEvents.slice(0, 5).map(e => `${e.summary} at ${e.start?.dateTime || e.start?.date}`).join(', ');
      const contextPrompt = `Extract key details from this travel request: "${query}". Origin: ${origin}, Destination: ${destination}. Also consider these upcoming calendar events: ${eventsSummary}. Return a short 1-line summary of the trip purpose.`;
      const contextRes = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: contextPrompt });
      contextResText = contextRes.text || 'Business Trip';
    } else {
      const contextPrompt = `Extract key details from this travel request: "${query}". Origin: ${origin}, Destination: ${destination}. Return a short 1-line summary of the trip purpose.`;
      const contextRes = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: contextPrompt });
      contextResText = contextRes.text || 'Business Trip';
    }
    
    onEvent({ type: 'CALENDAR_SCAN', status: 'complete', data: { events: [contextResText] } });

    // 2. Flight Search
    onEvent({ type: 'FLIGHT_SEARCH', status: 'searching', data: { text: `Searching flights: ${origin || 'Origin'} → ${destination || 'Destination'}...` } });
    const flightRes = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Find a real flight from ${origin || 'Origin'} to ${destination || 'Destination'}. Give me the airline, flight number, time, and approximate cost in one short line.`,
      config: { tools: [{ googleSearch: {} }] }
    });
    onEvent({ type: 'FLIGHT_SEARCH', status: 'found', data: { flights: [flightRes.text?.split('\n')[0] || 'IndiGo 6E-543 | 06:30 AM | ₹4,200 | On Time'] } });

    // 3. Disruption Simulation
    onEvent({ type: 'DISRUPTION_SIMULATION', status: 'checking', data: { text: 'Simulating flight disruptions and delays...' } });
    const disruptionRes = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `What are common flight disruptions for a trip from ${origin || 'Origin'} to ${destination || 'Destination'}? Give a 1-line risk assessment and 1 alternative transport mode.`,
    });
    onEvent({ type: 'DISRUPTION_SIMULATION', status: 'done', data: { risk: disruptionRes.text?.split('\n')[0] || 'Low disruption risk', alternatives: ['Train option available'] } });

    // 4. Weather Check
    onEvent({ type: 'WEATHER_CHECK', status: 'checking', data: { text: 'Checking weather at destination...' } });
    const weatherRes = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `What is the current weather in ${destination || 'Destination'}? Return just the temperature and condition (e.g., 18°C, Partly Cloudy).`,
      config: { tools: [{ googleSearch: {} }] }
    });
    onEvent({ type: 'WEATHER_CHECK', status: 'complete', data: { weather: { temp: weatherRes.text?.split(',')[0] || '18°C', condition: weatherRes.text?.split(',')[1] || 'Partly Cloudy' } } });

    // 5. Maps & Route Plan
    onEvent({ type: 'ROUTE_PLAN', status: 'calculating', data: { text: 'Calculating route: Airport → Hotel → Meeting venue' } });
    const routeRes = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Calculate a route from the airport in ${destination || 'Destination'} to the city center. Give distance and time in one short line.`,
      config: { tools: [{ googleMaps: {} }] }
    });
    onEvent({ type: 'ROUTE_PLAN', status: 'done', data: { routes: [routeRes.text?.split('\n')[0] || '14.2 km · 34 min via NH-48'] } });

    // 6. Criticality Scoring
    onEvent({ type: 'CRITICALITY', status: 'scoring', data: { text: 'Scoring business criticality of meetings...' } });
    await new Promise((r) => setTimeout(r, 1000));
    onEvent({ type: 'CRITICALITY', status: 'done', data: { scores: ['Meeting — 9/10 CRITICAL'] } });

    // 7. Place Suggestions
    if (tripPurpose?.toLowerCase().includes('leisure') || tags?.includes('Leisure')) {
      onEvent({ type: 'PLACE_SUGGEST', status: 'fetching', data: { text: 'Finding personalized places near your stops...' } });
      const placesRes = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Suggest one top tourist attraction in ${destination || 'Destination'}. Give name, rating, and short description in one line.`,
        config: { tools: [{ googleMaps: {} }] }
      });
      onEvent({ type: 'PLACE_SUGGEST', status: 'done', data: { places: [placesRes.text?.split('\n')[0] || "Humayun's Tomb · 4.8⭐"] } });
    }

    // 8. Plan Synthesis
    onEvent({ type: 'PLAN_COMPLETE', status: 'synthesizing', data: { text: 'Plan complete. Building your journey flowchart...' } });
    
    const eventsSummary = calendarEvents && calendarEvents.length > 0 
      ? `Upcoming Calendar Events: ${calendarEvents.slice(0, 5).map(e => `${e.summary} at ${e.start?.dateTime || e.start?.date}`).join(', ')}` 
      : '';

    const prompt = `
      You are an autonomous travel planning agent.
      Create a journey graph JSON for a trip from ${origin || 'Chennai'} to ${destination || 'Delhi'} for ${days || 3} days.
      Purpose: ${tripPurpose || 'Business'}.
      Stops: ${stops?.join(', ') || 'None'}.
      Budget: ${budget || 'Standard'}.
      ${eventsSummary}
      
      CRITICAL INSTRUCTIONS:
      1. Optimize the plan for the specified budget. If budget is 'Economy', prioritize cheaper transport and accommodations.
      2. Simulate potential disruptions (e.g., "Delayed by 2 hours", "Traffic jam") for transport nodes.
      3. Include alternative transport options in the node's data.alternatives array for any disrupted routes.
      4. If there are calendar events, ensure the travel plan accommodates them (e.g., arriving before a meeting).
      
      Return ONLY valid JSON matching this structure:
      {
        "nodes": [
          { "id": "node-1", "type": "location", "subtype": "airport", "label": "Origin Airport", "data": { "eta": "...", "details": "..." } },
          { "id": "node-2", "type": "transport", "subtype": "flight", "label": "Flight", "data": { "departure": "...", "arrival": "...", "cost": 4200, "status": "DELAYED", "alternatives": ["Train option available"] } }
        ],
        "edges": [
          { "id": "edge-1-2", "source": "node-1", "target": "node-2", "label": "Wait", "type": "wait" }
        ]
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            nodes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  type: { type: Type.STRING },
                  subtype: { type: Type.STRING },
                  label: { type: Type.STRING },
                  data: { type: Type.OBJECT }
                },
                required: ["id", "type", "subtype", "label", "data"]
              }
            },
            edges: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  source: { type: Type.STRING },
                  target: { type: Type.STRING },
                  label: { type: Type.STRING },
                  type: { type: Type.STRING }
                },
                required: ["id", "source", "target", "type"]
              }
            }
          },
          required: ["nodes", "edges"]
        }
      }
    });

    let text = response.text || '{}';
    text = text.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    const graphJson = JSON.parse(text);
    
    onEvent({ type: 'PLAN_COMPLETE', status: 'done', data: { graph: graphJson } });
    return graphJson;

  } catch (error) {
    console.error('Agent error:', error);
    onEvent({ type: 'ERROR', status: 'failed', data: { message: 'Agent encountered an error.' } });
    throw error;
  }
}

export async function updateNodeChat(
  params: { nodeId: string, userMessage: string, fullPlanContext: any },
  onEvent: (event: any) => void
) {
  const { nodeId, userMessage, fullPlanContext } = params;
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

  try {
    onEvent({ type: 'AGENT_THOUGHT', status: 'thinking', data: { text: 'Analyzing request for this leg...' } });
    await new Promise((r) => setTimeout(r, 1000));
    
    const prompt = `
      You are an autonomous travel agent modifying a specific leg of a journey.
      User request: "${userMessage}"
      Node ID to modify: ${nodeId}
      Current Plan Context: ${JSON.stringify(fullPlanContext)}
      
      Return a JSON object with the updated node data that replaces the old node.
      Format: { "updatedNode": { "id": "...", "type": "...", "subtype": "...", "label": "...", "data": { ... } } }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
      config: { 
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            updatedNode: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                type: { type: Type.STRING },
                subtype: { type: Type.STRING },
                label: { type: Type.STRING },
                data: { type: Type.OBJECT }
              },
              required: ["id", "type", "subtype", "label", "data"]
            }
          },
          required: ["updatedNode"]
        }
      }
    });

    let text = response.text || '{}';
    text = text.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    const result = JSON.parse(text);
    
    onEvent({ type: 'NODE_UPDATED', status: 'done', data: { updatedNode: result.updatedNode } });
    return result.updatedNode;
  } catch (error) {
    console.error('Node chat error:', error);
    onEvent({ type: 'ERROR', status: 'failed', data: { message: 'Failed to update node.' } });
    throw error;
  }
}
